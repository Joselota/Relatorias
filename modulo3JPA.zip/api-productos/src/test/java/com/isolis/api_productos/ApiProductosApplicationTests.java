package com.isolis.api_productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
