package com.isolis.api_productos_jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiProductosJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiProductosJdbcApplication.class, args);
	}

}
