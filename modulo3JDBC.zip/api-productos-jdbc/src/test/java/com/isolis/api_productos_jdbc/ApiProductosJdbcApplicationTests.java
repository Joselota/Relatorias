package com.isolis.api_productos_jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProductosJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
