import os, sqlite3
import pandas as pd
import matplotlib.pyplot as plt

DB_PATH = "empresa.db"
OUT_XLSX = "reporte_ventas.xlsx"

def setup_db():
    new = not os.path.exists(DB_PATH)
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    if new:
        cur.executescript("""
        CREATE TABLE empleados (id INTEGER PRIMARY KEY, nombre TEXT, depto_id INTEGER);
        CREATE TABLE departamentos (id INTEGER PRIMARY KEY, nombre TEXT);
        CREATE TABLE ventas (
          id INTEGER PRIMARY KEY,
          fecha TEXT, empleado_id INTEGER, producto TEXT,
          unidades INTEGER, precio_unitario REAL
        );
        """)
        cur.executemany("INSERT INTO departamentos (id, nombre) VALUES (?,?)",
                        [(1,"Ventas"),(2,"Soporte"),(3,"Finanzas")])
        cur.executemany("INSERT INTO empleados (id, nombre, depto_id) VALUES (?,?,?)",
                        [(1,"Ingrid",1),(2,"Alexis",1),(3,"Camila",2),(4,"Diego",1)])
        ventas = [
            ("2025-09-22", 1, "Producto A",  5, 10.0),
            ("2025-09-22", 2, "Producto B",  3, 15.0),
            ("2025-09-23", 1, "Producto A",  7, 10.0),
            ("2025-09-23", 4, "Producto A",  2, 10.0),
            ("2025-09-24", 2, "Producto C",  4, 20.0),
            ("2025-09-25", 1, "Producto B",  1, 15.0),
            ("2025-09-26", 3, "Producto Soporte", 10, 5.0),
            ("2025-09-26", 4, "Producto A",  6, 10.0),
            ("2025-09-27", 2, "Producto B",  2, 15.0),
        ]
        cur.executemany("INSERT INTO ventas (fecha, empleado_id, producto, unidades, precio_unitario) VALUES (?,?,?,?,?)", ventas)
        con.commit()
    return con

def generar_reporte(con, out_xlsx=OUT_XLSX):
    q = '''
    SELECT v.fecha, e.nombre AS empleado,
           v.producto, v.unidades, v.precio_unitario,
           v.unidades * v.precio_unitario AS monto
    FROM ventas v
    JOIN empleados e ON e.id = v.empleado_id
    '''
    df = pd.read_sql(q, con)
    df_resumen = df.groupby(['fecha','producto'], as_index=False)['monto'].sum()
    df_empleado = df.groupby('empleado', as_index=False)['monto'].sum()
    with pd.ExcelWriter(out_xlsx) as w:
        df.to_excel(w, sheet_name='Detalle', index=False)
        df_resumen.to_excel(w, sheet_name='Resumen', index=False)
        df_empleado.to_excel(w, sheet_name='PorEmpleado', index=False)
    # Gráfico
    plt.figure()
    plt.bar(df_empleado['empleado'], df_empleado['monto'])
    plt.title('Ventas por empleado'); plt.xlabel('Empleado'); plt.ylabel('Monto')
    plt.tight_layout()
    plt.savefig('ventas_por_empleado.png')
    print('Reporte generado:', out_xlsx)

if __name__ == '__main__':
    con = setup_db()
    try:
        generar_reporte(con)
    finally:
        con.close()
