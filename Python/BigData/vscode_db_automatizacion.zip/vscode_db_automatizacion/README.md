# Demo: Python + SQLite + Automatización

## Instrucciones
```bash
pip install -r requirements.txt
python main.py
```
Genera `empresa.db` con datos demo y `reporte_ventas.xlsx`.
